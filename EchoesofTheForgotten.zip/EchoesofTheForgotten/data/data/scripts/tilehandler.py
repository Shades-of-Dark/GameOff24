import pygame


class TileGroup(pygame.sprite.Group):
    def __init__(self):
        super().__init__()

